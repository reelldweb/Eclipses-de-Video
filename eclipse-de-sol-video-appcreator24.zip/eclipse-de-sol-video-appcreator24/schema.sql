-- Eclipse de Sol Video / Supabase production schema
create extension if not exists pgcrypto;
create table if not exists public.profiles(id uuid primary key references auth.users(id) on delete cascade,display_name text,role text not null default 'user' check(role in ('user','admin')),created_at timestamptz not null default now());
create table if not exists public.media(id uuid primary key default gen_random_uuid(),type text not null check(type in ('movie','series')),title text not null,description text,year int,genre text,poster_url text,trailer_url text,video_url text,imdb_id text,published boolean not null default true,created_at timestamptz not null default now());
create table if not exists public.favorites(user_id uuid not null references auth.users(id) on delete cascade,media_id uuid not null references public.media(id) on delete cascade,created_at timestamptz not null default now(),primary key(user_id,media_id));
create table if not exists public.watch_history(user_id uuid not null references auth.users(id) on delete cascade,media_id uuid not null references public.media(id) on delete cascade,progress_seconds int not null default 0,updated_at timestamptz not null default now(),primary key(user_id,media_id));
create table if not exists public.subscriptions(id uuid primary key default gen_random_uuid(),user_id uuid not null references auth.users(id) on delete cascade,plan text not null check(plan in ('free','premium','family')),status text not null default 'active',starts_at timestamptz not null default now(),ends_at timestamptz);
alter table public.profiles enable row level security; alter table public.media enable row level security; alter table public.favorites enable row level security; alter table public.watch_history enable row level security; alter table public.subscriptions enable row level security;
create policy "public published media" on public.media for select to anon,authenticated using (published=true or exists(select 1 from public.profiles p where p.id=auth.uid() and p.role='admin'));
create policy "own profile select" on public.profiles for select to authenticated using ((select auth.uid())=id);
create policy "own profile update" on public.profiles for update to authenticated using ((select auth.uid())=id) with check ((select auth.uid())=id);
create policy "own favorites" on public.favorites for all to authenticated using ((select auth.uid())=user_id) with check ((select auth.uid())=user_id);
create policy "own history" on public.watch_history for all to authenticated using ((select auth.uid())=user_id) with check ((select auth.uid())=user_id);
create policy "own subscriptions" on public.subscriptions for select to authenticated using ((select auth.uid())=user_id);
create or replace function public.handle_new_user() returns trigger language plpgsql security definer set search_path=public as $$ begin insert into public.profiles(id,display_name) values(new.id,coalesce(new.raw_user_meta_data->>'display_name',split_part(new.email,'@',1))) on conflict(id) do nothing; return new; end; $$;
drop trigger if exists on_auth_user_created on auth.users; create trigger on_auth_user_created after insert on auth.users for each row execute procedure public.handle_new_user();
-- After creating your own account, promote it manually in the SQL editor:
-- update public.profiles set role='admin' where id='YOUR-USER-UUID';
